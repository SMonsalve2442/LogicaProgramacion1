# Este codigo ha sido generado por el modulo psexport 20230904-w32 de PSeInt.
# Es posible que el codigo generado no sea completamente correcto. Si encuentra
# errores por favor reportelos en el foro (http://pseint.sourceforge.net).


if __name__ == '__main__':
	a = int()
	b = int()
	c = int()
	print("Ingrese el numero que desea asignar a A: ")
	a = int(input())
	print("Ingrese el numero que desea asignar a B: ")
	b = int(input())
	c = a+b
	print("La suma es: ",c)

